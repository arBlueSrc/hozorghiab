<?php session_start();
$_SESSION['userLoginStateLog'] == true;
header("location:../index.php?State=ok");
?>